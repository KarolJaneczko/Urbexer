﻿namespace APIpz.Entities
{
    public class Ranking
    {
        public int Id { get; set; }
    }
}