﻿namespace APIpz.Models
{
    public class DodajOdwiedzoneDto
    {
        public string NazwaUrbexu { get; set; }
    }
}
