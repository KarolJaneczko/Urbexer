﻿namespace APIpz.Models
{
    public class ConfirmUserDto
    {
        public string KodPotwierdzajacy { get; set; }
    }
}
